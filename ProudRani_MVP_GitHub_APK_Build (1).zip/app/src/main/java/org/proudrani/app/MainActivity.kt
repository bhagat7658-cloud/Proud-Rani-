package org.proudrani.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import android.graphics.Color
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val maroon = Color.rgb(151,30,57)
    private val cream = Color.rgb(250,247,244)
    private val ink = Color.rgb(35,31,34)
    private val anmol = "9055501242"
    private val aagriya = "9622191919"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildHome()
    }

    private fun buildHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 35, 28, 28)
            setBackgroundColor(cream)
        }

        val title = TextView(this).apply {
            text = "PROUD RANI"
            textSize = 30f
            setTextColor(maroon)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Women’s Safety Movement • Gen-Z of JKL"
            textSize = 15f
            setTextColor(ink)
            setPadding(0, 4, 0, 24)
        }
        root.addView(subtitle)

        val sos = Button(this).apply {
            text = "SOS"
            textSize = 30f
            setTextColor(Color.WHITE)
            setBackgroundColor(maroon)
            setOnClickListener { showSosDialog() }
        }
        root.addView(sos, LinearLayout.LayoutParams(-1, 180).apply { bottomMargin = 18 })

        addAction(root, "Call 112 — Emergency", maroon) { call("112") }
        addAction(root, "Call Anmol — 9055501242", ink) { call(anmol) }
        addAction(root, "Call Aagriya — 9622191919", ink) { call(aagriya) }
        addAction(root, "WhatsApp Helpline", ink) { openWhatsApp() }
        addAction(root, "Share My Location", ink) { shareLocation() }

        val note = TextView(this).apply {
            text = "If you are in immediate danger, prioritize emergency services. Do not rely only on the app."
            textSize = 12f
            setTextColor(Color.DKGRAY)
            setPadding(0, 22, 0, 0)
        }
        root.addView(note)
        setContentView(root)
    }

    private fun addAction(root: LinearLayout, label: String, color: Int, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = 15f
            setTextColor(if (color == maroon) Color.WHITE else ink)
            setBackgroundColor(if (color == maroon) maroon else Color.WHITE)
            setOnClickListener { action() }
        }
        root.addView(b, LinearLayout.LayoutParams(-1, 58).apply { bottomMargin = 10 })
    }

    private fun showSosDialog() {
        AlertDialog.Builder(this)
            .setTitle("Send SOS?")
            .setMessage("This will help you quickly contact emergency support and the Proud Rani core team.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Continue") { _, _ ->
                call("112")
            }.show()
    }

    private fun call(number: String) {
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CALL_PHONE), 100)
            return
        }
        startActivity(intent)
    }

    private fun openWhatsApp() {
        val uri = Uri.parse("https://wa.me/?text=I%20need%20help%20from%20Proud%20Rani.")
        startActivity(Intent(Intent.ACTION_VIEW, uri))
    }

    private fun shareLocation() {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                101
            )
            return
        }
        val loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
        val text = if (loc != null)
            "I need help. My approximate location: https://maps.google.com/?q=${loc.latitude},${loc.longitude}"
        else
            "I need help. I could not retrieve my location. Please call me."
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }, "Share location"))
    }
}
