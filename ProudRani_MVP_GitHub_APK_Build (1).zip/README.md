# Proud Rani — Android MVP

Free MVP starter for the Gen-Z of JKL Women Safety Movement.

## Included
- SOS button
- Call 112
- Call Anmol Ohri: 9055501242
- Call Aagriya Singh Chauhan: 9622191919
- WhatsApp action
- Location sharing
- Basic privacy/emergency warning

## Build
Open the folder in Android Studio and let Gradle sync.
Then run on an Android device.

## Important
This MVP intentionally does NOT claim to provide guaranteed background SOS,
silent alerts, SMS automation, or simultaneous multi-phone call routing.
Those require additional testing/permissions/backend infrastructure.
