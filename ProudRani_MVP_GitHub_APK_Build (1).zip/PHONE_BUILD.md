# Build APK from phone

1. Create a GitHub repository named `ProudRani`.
2. Upload the contents of this project to the repository root.
3. Open the **Actions** tab.
4. Select **Build Proud Rani APK**.
5. Tap **Run workflow**.
6. Wait for the green check.
7. Open the completed workflow run and download the artifact named **ProudRani-debug-apk**.
8. Extract the downloaded ZIP and install `app-debug.apk`.

No USB debugging is needed for this cloud build.
